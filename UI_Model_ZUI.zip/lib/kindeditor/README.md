# Kindeitor 使用须知

请将当前目录中的 `plugins.zip` 文件解压缩到当前目录，否则部分高级功能无法正常使用。
